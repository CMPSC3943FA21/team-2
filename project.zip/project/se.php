*{
	margin:0;
	padding:0;
}
body{
	height:100%;
	width:100%;

  margin:1px;
}
.a{height:900px;
	width:1200px;

	margin-left:auto;
	margin-right:auto;
	border:5px;
	border-color:red;
background-image: url("images (1).jpg");

  /* Center and scale the image nicely */
  
  background-repeat: no-repeat;
  background-size: cover;
  background-position:center;
}
.center {
margin: auto;
width: 60%;
border: 5px solid #FFFF00;
padding: 10px;
}
.b{ height:100px;
	width:1100px;
	margin-left:auto;
	margin-right:auto;
	border:5px;
	border-color:red;
	background-image: url("images (1).jpg");  
	background-repeat: no-repeat;
	background-size: cover;
	background-position:center;
  
}
.wrapper{
	margin:0 auto;
	width:1100px;
	height:700px;
}
.wrapper a{
	margin:1px;
	width:700px
}
#1{
	margin:5px;
	width:1000px;
}

nav{ width:100%;
height:100px;
background-color:white;
background-position:center;
position:relative;

}

ul{
	
	
}

ul li{ list-style: none;
	display:inline-block;
	float:right;
	line-height:100px;
	position:relative;
	left:-330px;
	
}

ul li a{
	display:block;
	text-decoration:none;
	font-size:14px;
	font-family:cursive;
	color:red;
	font-weight:bold;
	padding:0 20px;
	text-align:center;
	
}
ul li a:hover { color:brown;
}

div.gallery {
  border: 1px solid grey;
}

div.gallery:hover {
  border: 2px solid red;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}

* {
  box-sizing: border-box;
}

.responsive {
  padding: 0 6px;
  float: left;
  width: 33%;
}

@media only screen and (max-width: 800px) {
  .responsive {
    width: 49.99999%;
    margin: 6px 0;
  }
}

@media only screen and (max-width: 600px) {
  .responsive {
    width: 100%;
  }
}

.clearfix:after {
  content: "";
  display: table;
  clear: both;
}
.vl {
  border-left: 6px solid green;
  height: 500px;
  margin-left:auto;
  margin-right:auto;
}

